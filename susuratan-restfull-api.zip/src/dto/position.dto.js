const positionCreateDto = (data) => {
    return {
      name: data.name,
    };
  };
  
  module.exports = {
    positionCreateDto,
  };
  