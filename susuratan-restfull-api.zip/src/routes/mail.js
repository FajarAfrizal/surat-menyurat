const express = require('express');
const Route = express.Router();
const mail = require('../controllers/mail');

Route.get('/data', mail.findAll);
Route.get('/data/:id', mail.findOne);
Route.post('/create', mail.create);
Route.patch('/update/:id', mail.update);
Route.delete('/delete/:id', mail.deleted);
Route.get('/data/user/userId', mail.findAllUserId);

const routeProps = {
    Route,
    auth: true
}

module.exports = routeProps;