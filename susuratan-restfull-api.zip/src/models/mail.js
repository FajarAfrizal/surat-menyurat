const { PrismaClient } = require('@prisma/client');
const dbService =  new PrismaClient();

async function create(mailData, req) {
    return await dbService.mail.create({
        data: {
            user: {
                connect: { id: req.user.id }
            },
            about: mailData.about,
            from: mailData.from,
            mail_code: mailData.mail_code,
            date_of_letter: mailData.date_of_letter,
            date_of_receipt: mailData.date_of_receipt,
            notes: mailData.notes,
            expired: false,
            tendency: mailData.tendency,
            mail_type: mailData.mail_type
        }
    })
}

async function findAll(){
    return await dbService.mail.findMany({
        where: {
            deleted_at: null
        },
        include: {
            user: true
        }
    })
}

async function findAllByUserId(userId) {
    return await dbService.mail.findMany({
        where: {
            user_id: userId,
            deleted_at: null
        },
        include:{
            user: true
        }
    })
  }

async function findOne(id) {
    return await dbService.mail.findFirst({
        where: {
            id,
            deleted_at: null
        },
        include: {
            user: true
        }
    })
}

async function update(updateDto, id, req){ 
    return await dbService.mail.update({
        where: {
            id,
        },
        data: {
            user: {
                connect: { id: req.user.id }
            },
            about: updateDto.about,
            form: updateDto.form,
            mail_code: updateDto.mail_code,
            date_of_letter: updateDto.date_of_letter,
            date_of_receipt: updateDto.date_of_receipt,
            notes: updateDto.notes,
            expired: updateDto.expired,
            tendency: updateDto.tendency,
            mail_type: updateDto.mail_type,
            updated_at: new Date()
        }
    })
}

async function deleted(id) {
    return await dbService.mail.update({
        where: {
            id
        },
        data: {
            deleted_at: new Date()
        }
    })
} 


module.exports = {
    create,
    findAll,
    findOne,
    update,
    deleted,
    findAllByUserId
}